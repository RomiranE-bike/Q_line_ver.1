namespace PradazehComputerVision
{
    partial class ComputerVision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
       protected override void Dispose(bool disposing)
        {
            ReleaseData();
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        } 

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ComputerVision));
            this.originalImageBox = new Emgu.CV.UI.ImageBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cannyImageBox = new Emgu.CV.UI.ImageBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.cameraCaptureButton = new System.Windows.Forms.Button();
            this.grayscaleImageBox = new Emgu.CV.UI.ImageBox();
            this.RedComboBox = new System.Windows.Forms.ComboBox();
            this.GreenComboBox = new System.Windows.Forms.ComboBox();
            this.BlueComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.ColorSelectButton = new System.Windows.Forms.Button();
            this.RedMinTextBox = new System.Windows.Forms.TextBox();
            this.ResultMaxTextBox = new System.Windows.Forms.TextBox();
            this.GreenMinTextBox = new System.Windows.Forms.TextBox();
            this.RedMaxTextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.BlueMaxTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ResultMinTextBox = new System.Windows.Forms.TextBox();
            this.GreenMaxTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.BlueMinTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ToleranceComboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.CircleImageBox = new Emgu.CV.UI.ImageBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FaceDetectionTimer = new System.Windows.Forms.Timer(this.components);
            this.ColorDetectionTimer = new System.Windows.Forms.Timer(this.components);
            this.Color_RectImageBox = new Emgu.CV.UI.ImageBox();
            this.Thershold_TriangelImageBox = new Emgu.CV.UI.ImageBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.restButton = new System.Windows.Forms.Button();
            this.stopcolorButton = new System.Windows.Forms.Button();
            this.colordetectButton = new System.Windows.Forms.Button();
            this.FlipVButton = new System.Windows.Forms.Button();
            this.FlipHButton = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.WriteButton = new System.Windows.Forms.Button();
            this.ReadButton = new System.Windows.Forms.Button();
            this.SettingPortButton = new System.Windows.Forms.Button();
            this.TimeOutLabel = new System.Windows.Forms.Label();
            this.SaveSettingButton = new System.Windows.Forms.Button();
            this.StopBitsLabel = new System.Windows.Forms.Label();
            this.ParityLabel = new System.Windows.Forms.Label();
            this.DataBitsLabel = new System.Windows.Forms.Label();
            this.BaudRateLabel = new System.Windows.Forms.Label();
            this.PortNameLabel = new System.Windows.Forms.Label();
            this.ClosePortButton = new System.Windows.Forms.Button();
            this.PortStatusLabel = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.stopbitscomboBox = new System.Windows.Forms.ComboBox();
            this.paritycomboBox = new System.Windows.Forms.ComboBox();
            this.databitscomboBox = new System.Windows.Forms.ComboBox();
            this.baudratecomboBox = new System.Windows.Forms.ComboBox();
            this.portnamecomboBox = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.readtextBox = new System.Windows.Forms.TextBox();
            this.writetextBox = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.ylabel = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.His_LineImageBox = new Emgu.CV.UI.ImageBox();
            this.xlabel = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cameraCaptureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shapeDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.featureExtractionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.faceDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.histogaramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.shapedetectButton = new System.Windows.Forms.Button();
            this.ShapeDetectionTimer = new System.Windows.Forms.Timer(this.components);
            this.stopShapeButton = new System.Windows.Forms.Button();
            this.faceDetectButton = new System.Windows.Forms.Button();
            this.stopFaceButton = new System.Windows.Forms.Button();
            this.PortTimer = new System.Windows.Forms.Timer(this.components);
            this.motionDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.originalImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cannyImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayscaleImageBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CircleImageBox)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Color_RectImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Thershold_TriangelImageBox)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.His_LineImageBox)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.SuspendLayout();
            // 
            // originalImageBox
            // 
            this.originalImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.originalImageBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.originalImageBox.Location = new System.Drawing.Point(8, 17);
            this.originalImageBox.Name = "originalImageBox";
            this.originalImageBox.Size = new System.Drawing.Size(255, 200);
            this.originalImageBox.TabIndex = 1;
            this.originalImageBox.TabStop = false;
            this.originalImageBox.Click += new System.EventHandler(this.originalImageBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 0;
            // 
            // cannyImageBox
            // 
            this.cannyImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cannyImageBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.cannyImageBox.Location = new System.Drawing.Point(9, 19);
            this.cannyImageBox.Name = "cannyImageBox";
            this.cannyImageBox.Size = new System.Drawing.Size(255, 200);
            this.cannyImageBox.TabIndex = 1;
            this.cannyImageBox.TabStop = false;
            this.cannyImageBox.Click += new System.EventHandler(this.cannyImageBox_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(711, 13);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(125, 35);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // cameraCaptureButton
            // 
            this.cameraCaptureButton.Enabled = false;
            this.cameraCaptureButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cameraCaptureButton.Location = new System.Drawing.Point(46, 285);
            this.cameraCaptureButton.Name = "cameraCaptureButton";
            this.cameraCaptureButton.Size = new System.Drawing.Size(255, 35);
            this.cameraCaptureButton.TabIndex = 0;
            this.cameraCaptureButton.Text = "CameraCapture";
            this.cameraCaptureButton.UseVisualStyleBackColor = true;
            this.cameraCaptureButton.Click += new System.EventHandler(this.CameraCapture_Click);
            // 
            // grayscaleImageBox
            // 
            this.grayscaleImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grayscaleImageBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.grayscaleImageBox.Location = new System.Drawing.Point(9, 19);
            this.grayscaleImageBox.Name = "grayscaleImageBox";
            this.grayscaleImageBox.Size = new System.Drawing.Size(255, 200);
            this.grayscaleImageBox.TabIndex = 3;
            this.grayscaleImageBox.TabStop = false;
            this.grayscaleImageBox.Click += new System.EventHandler(this.grayscaleImageBox_Click);
            // 
            // RedComboBox
            // 
            this.RedComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
            this.RedComboBox.FormattingEnabled = true;
            this.RedComboBox.Items.AddRange(new object[] {
            "0",
            "5",
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100",
            "110",
            "120",
            "130",
            "140",
            "150",
            "160",
            "170",
            "180",
            "190",
            "200",
            "210",
            "220",
            "230",
            "240",
            "250",
            "255"});
            this.RedComboBox.Location = new System.Drawing.Point(86, 73);
            this.RedComboBox.Name = "RedComboBox";
            this.RedComboBox.Size = new System.Drawing.Size(59, 21);
            this.RedComboBox.TabIndex = 5;
            this.RedComboBox.Text = "100";
            // 
            // GreenComboBox
            // 
            this.GreenComboBox.FormattingEnabled = true;
            this.GreenComboBox.Items.AddRange(new object[] {
            "0",
            "5",
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100",
            "110",
            "120",
            "130",
            "140",
            "150",
            "160",
            "170",
            "180",
            "190",
            "200",
            "210",
            "220",
            "230",
            "240",
            "250",
            "255"});
            this.GreenComboBox.Location = new System.Drawing.Point(86, 46);
            this.GreenComboBox.Name = "GreenComboBox";
            this.GreenComboBox.Size = new System.Drawing.Size(59, 21);
            this.GreenComboBox.TabIndex = 6;
            this.GreenComboBox.Text = "140";
            // 
            // BlueComboBox
            // 
            this.BlueComboBox.FormattingEnabled = true;
            this.BlueComboBox.Items.AddRange(new object[] {
            "0",
            "5",
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100",
            "110",
            "120",
            "130",
            "140",
            "150",
            "160",
            "170",
            "180",
            "190",
            "200",
            "210",
            "220",
            "230",
            "240",
            "250",
            "255"});
            this.BlueComboBox.Location = new System.Drawing.Point(86, 19);
            this.BlueComboBox.Name = "BlueComboBox";
            this.BlueComboBox.Size = new System.Drawing.Size(59, 21);
            this.BlueComboBox.TabIndex = 7;
            this.BlueComboBox.Text = "80";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.ToleranceComboBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.RedComboBox);
            this.groupBox1.Controls.Add(this.BlueComboBox);
            this.groupBox1.Controls.Add(this.GreenComboBox);
            this.groupBox1.Location = new System.Drawing.Point(1174, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(184, 322);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ColorSelection";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.ColorSelectButton);
            this.groupBox11.Controls.Add(this.RedMinTextBox);
            this.groupBox11.Controls.Add(this.ResultMaxTextBox);
            this.groupBox11.Controls.Add(this.GreenMinTextBox);
            this.groupBox11.Controls.Add(this.RedMaxTextBox);
            this.groupBox11.Controls.Add(this.label11);
            this.groupBox11.Controls.Add(this.BlueMaxTextBox);
            this.groupBox11.Controls.Add(this.label10);
            this.groupBox11.Controls.Add(this.label2);
            this.groupBox11.Controls.Add(this.ResultMinTextBox);
            this.groupBox11.Controls.Add(this.GreenMaxTextBox);
            this.groupBox11.Controls.Add(this.label9);
            this.groupBox11.Controls.Add(this.label4);
            this.groupBox11.Controls.Add(this.BlueMinTextBox);
            this.groupBox11.Controls.Add(this.label8);
            this.groupBox11.Location = new System.Drawing.Point(6, 132);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(172, 183);
            this.groupBox11.TabIndex = 28;
            this.groupBox11.TabStop = false;
            // 
            // ColorSelectButton
            // 
            this.ColorSelectButton.Enabled = false;
            this.ColorSelectButton.Location = new System.Drawing.Point(15, 135);
            this.ColorSelectButton.Name = "ColorSelectButton";
            this.ColorSelectButton.Size = new System.Drawing.Size(140, 35);
            this.ColorSelectButton.TabIndex = 27;
            this.ColorSelectButton.Text = "Select";
            this.ColorSelectButton.UseVisualStyleBackColor = true;
            this.ColorSelectButton.Click += new System.EventHandler(this.ColorSelectButton_Click);
            // 
            // RedMinTextBox
            // 
            this.RedMinTextBox.Location = new System.Drawing.Point(65, 76);
            this.RedMinTextBox.Name = "RedMinTextBox";
            this.RedMinTextBox.Size = new System.Drawing.Size(40, 20);
            this.RedMinTextBox.TabIndex = 11;
            // 
            // ResultMaxTextBox
            // 
            this.ResultMaxTextBox.Location = new System.Drawing.Point(114, 102);
            this.ResultMaxTextBox.Name = "ResultMaxTextBox";
            this.ResultMaxTextBox.Size = new System.Drawing.Size(40, 20);
            this.ResultMaxTextBox.TabIndex = 26;
            // 
            // GreenMinTextBox
            // 
            this.GreenMinTextBox.Location = new System.Drawing.Point(65, 50);
            this.GreenMinTextBox.Name = "GreenMinTextBox";
            this.GreenMinTextBox.Size = new System.Drawing.Size(40, 20);
            this.GreenMinTextBox.TabIndex = 23;
            // 
            // RedMaxTextBox
            // 
            this.RedMaxTextBox.Location = new System.Drawing.Point(114, 76);
            this.RedMaxTextBox.Name = "RedMaxTextBox";
            this.RedMaxTextBox.Size = new System.Drawing.Size(40, 20);
            this.RedMaxTextBox.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Result:";
            // 
            // BlueMaxTextBox
            // 
            this.BlueMaxTextBox.Location = new System.Drawing.Point(114, 24);
            this.BlueMaxTextBox.Name = "BlueMaxTextBox";
            this.BlueMaxTextBox.Size = new System.Drawing.Size(40, 20);
            this.BlueMaxTextBox.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(12, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Blue:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Min";
            // 
            // ResultMinTextBox
            // 
            this.ResultMinTextBox.Location = new System.Drawing.Point(65, 102);
            this.ResultMinTextBox.Name = "ResultMinTextBox";
            this.ResultMinTextBox.Size = new System.Drawing.Size(40, 20);
            this.ResultMinTextBox.TabIndex = 21;
            // 
            // GreenMaxTextBox
            // 
            this.GreenMaxTextBox.Location = new System.Drawing.Point(114, 50);
            this.GreenMaxTextBox.Name = "GreenMaxTextBox";
            this.GreenMaxTextBox.Size = new System.Drawing.Size(40, 20);
            this.GreenMaxTextBox.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Lime;
            this.label9.Location = new System.Drawing.Point(12, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Green:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(126, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Max";
            // 
            // BlueMinTextBox
            // 
            this.BlueMinTextBox.Location = new System.Drawing.Point(65, 24);
            this.BlueMinTextBox.Name = "BlueMinTextBox";
            this.BlueMinTextBox.Size = new System.Drawing.Size(40, 20);
            this.BlueMinTextBox.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(11, 79);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Red:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Tolerance:";
            // 
            // ToleranceComboBox
            // 
            this.ToleranceComboBox.FormattingEnabled = true;
            this.ToleranceComboBox.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.ToleranceComboBox.Location = new System.Drawing.Point(86, 100);
            this.ToleranceComboBox.Name = "ToleranceComboBox";
            this.ToleranceComboBox.Size = new System.Drawing.Size(59, 21);
            this.ToleranceComboBox.TabIndex = 15;
            this.ToleranceComboBox.Text = "40";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Blue:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Green:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Red:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox15);
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(18, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1143, 252);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.CircleImageBox);
            this.groupBox15.Location = new System.Drawing.Point(848, 19);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(270, 225);
            this.groupBox15.TabIndex = 3;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "CircleShape";
            // 
            // CircleImageBox
            // 
            this.CircleImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CircleImageBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.CircleImageBox.Location = new System.Drawing.Point(9, 19);
            this.CircleImageBox.Name = "CircleImageBox";
            this.CircleImageBox.Size = new System.Drawing.Size(255, 200);
            this.CircleImageBox.TabIndex = 1;
            this.CircleImageBox.TabStop = false;
            this.CircleImageBox.Click += new System.EventHandler(this.CircleImageBox_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.grayscaleImageBox);
            this.groupBox5.Location = new System.Drawing.Point(296, 19);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(270, 225);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "GrayScaleImage";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cannyImageBox);
            this.groupBox4.Location = new System.Drawing.Point(572, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(270, 225);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "CannyEdgeDetection";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.originalImageBox);
            this.groupBox3.Location = new System.Drawing.Point(20, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(270, 225);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "OriginalImage";
            // 
            // FaceDetectionTimer
            // 
            this.FaceDetectionTimer.Interval = 25;
            this.FaceDetectionTimer.Tick += new System.EventHandler(this.FaceDetectionTimer_Tick);
            // 
            // ColorDetectionTimer
            // 
            this.ColorDetectionTimer.Interval = 25;
            this.ColorDetectionTimer.Tick += new System.EventHandler(this.ColorDetectionTimer_Tick);
            // 
            // Color_RectImageBox
            // 
            this.Color_RectImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Color_RectImageBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Color_RectImageBox.Location = new System.Drawing.Point(9, 19);
            this.Color_RectImageBox.Name = "Color_RectImageBox";
            this.Color_RectImageBox.Size = new System.Drawing.Size(255, 200);
            this.Color_RectImageBox.TabIndex = 3;
            this.Color_RectImageBox.TabStop = false;
            this.Color_RectImageBox.Click += new System.EventHandler(this.Color_RectImageBox_Click);
            // 
            // Thershold_TriangelImageBox
            // 
            this.Thershold_TriangelImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Thershold_TriangelImageBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Thershold_TriangelImageBox.Location = new System.Drawing.Point(9, 19);
            this.Thershold_TriangelImageBox.Name = "Thershold_TriangelImageBox";
            this.Thershold_TriangelImageBox.Size = new System.Drawing.Size(255, 200);
            this.Thershold_TriangelImageBox.TabIndex = 4;
            this.Thershold_TriangelImageBox.TabStop = false;
            this.Thershold_TriangelImageBox.Click += new System.EventHandler(this.Thershold_TriangelImageBox_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Color_RectImageBox);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(20, 19);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(270, 225);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "ColorDetection/RectangelShape";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Thershold_TriangelImageBox);
            this.groupBox7.Location = new System.Drawing.Point(296, 19);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(270, 225);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Thresholding/TriangelShape";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.restButton);
            this.groupBox8.Controls.Add(this.stopcolorButton);
            this.groupBox8.Controls.Add(this.colordetectButton);
            this.groupBox8.Controls.Add(this.FlipVButton);
            this.groupBox8.Controls.Add(this.FlipHButton);
            this.groupBox8.Controls.Add(this.exitButton);
            this.groupBox8.Location = new System.Drawing.Point(18, 604);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(855, 55);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            // 
            // restButton
            // 
            this.restButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restButton.Location = new System.Drawing.Point(581, 13);
            this.restButton.Name = "restButton";
            this.restButton.Size = new System.Drawing.Size(125, 35);
            this.restButton.TabIndex = 17;
            this.restButton.Text = "Reset";
            this.restButton.UseVisualStyleBackColor = true;
            this.restButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // stopcolorButton
            // 
            this.stopcolorButton.Enabled = false;
            this.stopcolorButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stopcolorButton.Location = new System.Drawing.Point(159, 13);
            this.stopcolorButton.Name = "stopcolorButton";
            this.stopcolorButton.Size = new System.Drawing.Size(125, 35);
            this.stopcolorButton.TabIndex = 16;
            this.stopcolorButton.Text = "StopColor";
            this.stopcolorButton.UseVisualStyleBackColor = true;
            this.stopcolorButton.Click += new System.EventHandler(this.stopcolorButton_Click);
            // 
            // colordetectButton
            // 
            this.colordetectButton.Enabled = false;
            this.colordetectButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colordetectButton.Location = new System.Drawing.Point(28, 13);
            this.colordetectButton.Name = "colordetectButton";
            this.colordetectButton.Size = new System.Drawing.Size(125, 35);
            this.colordetectButton.TabIndex = 14;
            this.colordetectButton.Text = "ColorDetect";
            this.colordetectButton.UseVisualStyleBackColor = true;
            this.colordetectButton.Click += new System.EventHandler(this.colordetectButton_Click);
            // 
            // FlipVButton
            // 
            this.FlipVButton.Enabled = false;
            this.FlipVButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlipVButton.Location = new System.Drawing.Point(435, 13);
            this.FlipVButton.Name = "FlipVButton";
            this.FlipVButton.Size = new System.Drawing.Size(125, 35);
            this.FlipVButton.TabIndex = 13;
            this.FlipVButton.Text = "FlipVertical";
            this.FlipVButton.UseVisualStyleBackColor = true;
            this.FlipVButton.Click += new System.EventHandler(this.FlipVButton_Click);
            // 
            // FlipHButton
            // 
            this.FlipHButton.Enabled = false;
            this.FlipHButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlipHButton.Location = new System.Drawing.Point(305, 13);
            this.FlipHButton.Name = "FlipHButton";
            this.FlipHButton.Size = new System.Drawing.Size(125, 35);
            this.FlipHButton.TabIndex = 12;
            this.FlipHButton.Text = "FlipHorizantal";
            this.FlipHButton.UseVisualStyleBackColor = true;
            this.FlipHButton.Click += new System.EventHandler(this.FlipHButton_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.WriteButton);
            this.groupBox14.Controls.Add(this.ReadButton);
            this.groupBox14.Controls.Add(this.SettingPortButton);
            this.groupBox14.Controls.Add(this.TimeOutLabel);
            this.groupBox14.Controls.Add(this.SaveSettingButton);
            this.groupBox14.Controls.Add(this.StopBitsLabel);
            this.groupBox14.Controls.Add(this.ParityLabel);
            this.groupBox14.Controls.Add(this.DataBitsLabel);
            this.groupBox14.Controls.Add(this.BaudRateLabel);
            this.groupBox14.Controls.Add(this.PortNameLabel);
            this.groupBox14.Controls.Add(this.ClosePortButton);
            this.groupBox14.Controls.Add(this.PortStatusLabel);
            this.groupBox14.Location = new System.Drawing.Point(11, 159);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(259, 181);
            this.groupBox14.TabIndex = 4;
            this.groupBox14.TabStop = false;
            // 
            // WriteButton
            // 
            this.WriteButton.Enabled = false;
            this.WriteButton.Location = new System.Drawing.Point(176, 138);
            this.WriteButton.Name = "WriteButton";
            this.WriteButton.Size = new System.Drawing.Size(75, 25);
            this.WriteButton.TabIndex = 14;
            this.WriteButton.Text = "Write";
            this.WriteButton.UseVisualStyleBackColor = true;
            this.WriteButton.Click += new System.EventHandler(this.WriteButton_Click);
            // 
            // ReadButton
            // 
            this.ReadButton.Enabled = false;
            this.ReadButton.Location = new System.Drawing.Point(176, 109);
            this.ReadButton.Name = "ReadButton";
            this.ReadButton.Size = new System.Drawing.Size(75, 25);
            this.ReadButton.TabIndex = 13;
            this.ReadButton.Text = "Read";
            this.ReadButton.UseVisualStyleBackColor = true;
            this.ReadButton.Click += new System.EventHandler(this.ReadButton_Click);
            // 
            // SettingPortButton
            // 
            this.SettingPortButton.Location = new System.Drawing.Point(176, 20);
            this.SettingPortButton.Name = "SettingPortButton";
            this.SettingPortButton.Size = new System.Drawing.Size(75, 25);
            this.SettingPortButton.TabIndex = 12;
            this.SettingPortButton.Text = "SettingPort";
            this.SettingPortButton.UseVisualStyleBackColor = true;
            this.SettingPortButton.Click += new System.EventHandler(this.SettingPortButton_Click);
            // 
            // TimeOutLabel
            // 
            this.TimeOutLabel.AutoSize = true;
            this.TimeOutLabel.Location = new System.Drawing.Point(7, 41);
            this.TimeOutLabel.Name = "TimeOutLabel";
            this.TimeOutLabel.Size = new System.Drawing.Size(42, 13);
            this.TimeOutLabel.TabIndex = 6;
            this.TimeOutLabel.Text = "Timout:";
            // 
            // SaveSettingButton
            // 
            this.SaveSettingButton.Enabled = false;
            this.SaveSettingButton.Location = new System.Drawing.Point(176, 49);
            this.SaveSettingButton.Name = "SaveSettingButton";
            this.SaveSettingButton.Size = new System.Drawing.Size(75, 25);
            this.SaveSettingButton.TabIndex = 11;
            this.SaveSettingButton.Text = "SaveSetting";
            this.SaveSettingButton.UseVisualStyleBackColor = true;
            this.SaveSettingButton.Click += new System.EventHandler(this.SaveSettingButton_Click);
            // 
            // StopBitsLabel
            // 
            this.StopBitsLabel.AutoSize = true;
            this.StopBitsLabel.Location = new System.Drawing.Point(7, 153);
            this.StopBitsLabel.Name = "StopBitsLabel";
            this.StopBitsLabel.Size = new System.Drawing.Size(49, 13);
            this.StopBitsLabel.TabIndex = 5;
            this.StopBitsLabel.Text = "StopBits:";
            // 
            // ParityLabel
            // 
            this.ParityLabel.AutoSize = true;
            this.ParityLabel.Location = new System.Drawing.Point(7, 131);
            this.ParityLabel.Name = "ParityLabel";
            this.ParityLabel.Size = new System.Drawing.Size(36, 13);
            this.ParityLabel.TabIndex = 4;
            this.ParityLabel.Text = "Parity:";
            // 
            // DataBitsLabel
            // 
            this.DataBitsLabel.AutoSize = true;
            this.DataBitsLabel.Location = new System.Drawing.Point(7, 109);
            this.DataBitsLabel.Name = "DataBitsLabel";
            this.DataBitsLabel.Size = new System.Drawing.Size(50, 13);
            this.DataBitsLabel.TabIndex = 3;
            this.DataBitsLabel.Text = "DataBits:";
            // 
            // BaudRateLabel
            // 
            this.BaudRateLabel.AutoSize = true;
            this.BaudRateLabel.Location = new System.Drawing.Point(7, 86);
            this.BaudRateLabel.Name = "BaudRateLabel";
            this.BaudRateLabel.Size = new System.Drawing.Size(58, 13);
            this.BaudRateLabel.TabIndex = 2;
            this.BaudRateLabel.Text = "BaudRate:";
            // 
            // PortNameLabel
            // 
            this.PortNameLabel.AutoSize = true;
            this.PortNameLabel.Location = new System.Drawing.Point(7, 63);
            this.PortNameLabel.Name = "PortNameLabel";
            this.PortNameLabel.Size = new System.Drawing.Size(57, 13);
            this.PortNameLabel.TabIndex = 1;
            this.PortNameLabel.Text = "PortName:";
            // 
            // ClosePortButton
            // 
            this.ClosePortButton.Location = new System.Drawing.Point(176, 78);
            this.ClosePortButton.Name = "ClosePortButton";
            this.ClosePortButton.Size = new System.Drawing.Size(75, 25);
            this.ClosePortButton.TabIndex = 5;
            this.ClosePortButton.Text = "ClosePort";
            this.ClosePortButton.UseVisualStyleBackColor = true;
            this.ClosePortButton.Click += new System.EventHandler(this.ClosePortButton_Click);
            // 
            // PortStatusLabel
            // 
            this.PortStatusLabel.AutoSize = true;
            this.PortStatusLabel.Location = new System.Drawing.Point(7, 20);
            this.PortStatusLabel.Name = "PortStatusLabel";
            this.PortStatusLabel.Size = new System.Drawing.Size(59, 13);
            this.PortStatusLabel.TabIndex = 0;
            this.PortStatusLabel.Text = "PortStatus:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label16);
            this.groupBox13.Controls.Add(this.label15);
            this.groupBox13.Controls.Add(this.label14);
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.label12);
            this.groupBox13.Controls.Add(this.stopbitscomboBox);
            this.groupBox13.Controls.Add(this.paritycomboBox);
            this.groupBox13.Controls.Add(this.databitscomboBox);
            this.groupBox13.Controls.Add(this.baudratecomboBox);
            this.groupBox13.Controls.Add(this.portnamecomboBox);
            this.groupBox13.Location = new System.Drawing.Point(21, 17);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(140, 273);
            this.groupBox13.TabIndex = 3;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Setting";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 182);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 13);
            this.label16.TabIndex = 10;
            this.label16.Text = "StopBits:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 146);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 13);
            this.label15.TabIndex = 9;
            this.label15.Text = "Parity:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 111);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "DataBits:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 76);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "BaudRate:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "PortNeme:";
            // 
            // stopbitscomboBox
            // 
            this.stopbitscomboBox.FormattingEnabled = true;
            this.stopbitscomboBox.Items.AddRange(new object[] {
            "None",
            "One",
            "Tow",
            "OnePointFive"});
            this.stopbitscomboBox.Location = new System.Drawing.Point(80, 179);
            this.stopbitscomboBox.Name = "stopbitscomboBox";
            this.stopbitscomboBox.Size = new System.Drawing.Size(50, 21);
            this.stopbitscomboBox.TabIndex = 4;
            this.stopbitscomboBox.Text = "One";
            // 
            // paritycomboBox
            // 
            this.paritycomboBox.FormattingEnabled = true;
            this.paritycomboBox.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.paritycomboBox.Location = new System.Drawing.Point(80, 143);
            this.paritycomboBox.Name = "paritycomboBox";
            this.paritycomboBox.Size = new System.Drawing.Size(50, 21);
            this.paritycomboBox.TabIndex = 3;
            this.paritycomboBox.Text = "None";
            // 
            // databitscomboBox
            // 
            this.databitscomboBox.FormattingEnabled = true;
            this.databitscomboBox.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.databitscomboBox.Location = new System.Drawing.Point(80, 108);
            this.databitscomboBox.Name = "databitscomboBox";
            this.databitscomboBox.Size = new System.Drawing.Size(50, 21);
            this.databitscomboBox.TabIndex = 2;
            this.databitscomboBox.Text = "8";
            // 
            // baudratecomboBox
            // 
            this.baudratecomboBox.FormattingEnabled = true;
            this.baudratecomboBox.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "14400",
            "19200"});
            this.baudratecomboBox.Location = new System.Drawing.Point(80, 72);
            this.baudratecomboBox.Name = "baudratecomboBox";
            this.baudratecomboBox.Size = new System.Drawing.Size(50, 21);
            this.baudratecomboBox.TabIndex = 1;
            this.baudratecomboBox.Text = "9600";
            // 
            // portnamecomboBox
            // 
            this.portnamecomboBox.FormattingEnabled = true;
            this.portnamecomboBox.Items.AddRange(new object[] {
            "COM1",
            "COM3",
            "COM5",
            "COM10",
            "COM11",
            "COM16"});
            this.portnamecomboBox.Location = new System.Drawing.Point(80, 37);
            this.portnamecomboBox.Name = "portnamecomboBox";
            this.portnamecomboBox.Size = new System.Drawing.Size(50, 21);
            this.portnamecomboBox.TabIndex = 0;
            this.portnamecomboBox.Text = "COM11";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label24);
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Controls.Add(this.readtextBox);
            this.groupBox12.Controls.Add(this.writetextBox);
            this.groupBox12.Location = new System.Drawing.Point(11, 19);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(259, 134);
            this.groupBox12.TabIndex = 2;
            this.groupBox12.TabStop = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 68);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 13);
            this.label24.TabIndex = 3;
            this.label24.Text = "Write:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 13);
            this.label23.TabIndex = 2;
            this.label23.Text = "Read:";
            // 
            // readtextBox
            // 
            this.readtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.readtextBox.Location = new System.Drawing.Point(9, 35);
            this.readtextBox.Name = "readtextBox";
            this.readtextBox.Size = new System.Drawing.Size(237, 26);
            this.readtextBox.TabIndex = 0;
            // 
            // writetextBox
            // 
            this.writetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.writetextBox.Location = new System.Drawing.Point(9, 86);
            this.writetextBox.Name = "writetextBox";
            this.writetextBox.Size = new System.Drawing.Size(237, 26);
            this.writetextBox.TabIndex = 1;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.ylabel);
            this.groupBox10.Controls.Add(this.groupBox16);
            this.groupBox10.Controls.Add(this.groupBox6);
            this.groupBox10.Controls.Add(this.xlabel);
            this.groupBox10.Controls.Add(this.groupBox7);
            this.groupBox10.Location = new System.Drawing.Point(18, 320);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(855, 281);
            this.groupBox10.TabIndex = 14;
            this.groupBox10.TabStop = false;
            // 
            // ylabel
            // 
            this.ylabel.AutoSize = true;
            this.ylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ylabel.Location = new System.Drawing.Point(76, 247);
            this.ylabel.Name = "ylabel";
            this.ylabel.Size = new System.Drawing.Size(18, 16);
            this.ylabel.TabIndex = 18;
            this.ylabel.Text = "y:";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.His_LineImageBox);
            this.groupBox16.Location = new System.Drawing.Point(572, 19);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(270, 225);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Histogram/LineShape";
            // 
            // His_LineImageBox
            // 
            this.His_LineImageBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.His_LineImageBox.Cursor = System.Windows.Forms.Cursors.Cross;
            this.His_LineImageBox.Location = new System.Drawing.Point(9, 19);
            this.His_LineImageBox.Name = "His_LineImageBox";
            this.His_LineImageBox.Size = new System.Drawing.Size(255, 200);
            this.His_LineImageBox.TabIndex = 4;
            this.His_LineImageBox.TabStop = false;
            this.His_LineImageBox.Click += new System.EventHandler(this.His_LineImageBox_Click);
            // 
            // xlabel
            // 
            this.xlabel.AutoSize = true;
            this.xlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xlabel.Location = new System.Drawing.Point(26, 247);
            this.xlabel.Name = "xlabel";
            this.xlabel.Size = new System.Drawing.Size(17, 16);
            this.xlabel.TabIndex = 17;
            this.xlabel.Text = "x:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.sToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1370, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.toolStripSeparator,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.newToolStripMenuItem.Text = "&New";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
            this.openToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.openToolStripMenuItem.Text = "&Open";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(143, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
            this.saveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.saveToolStripMenuItem.Text = "&Save";
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.saveAsToolStripMenuItem.Text = "Save &As";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(143, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem.Image")));
            this.printToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.printToolStripMenuItem.Text = "&Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Pre&view";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(143, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator3,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator4,
            this.selectAllToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.undoToolStripMenuItem.Text = "&Undo";
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.redoToolStripMenuItem.Text = "&Redo";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(141, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
            this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.cutToolStripMenuItem.Text = "Cu&t";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem.Image")));
            this.copyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem.Image")));
            this.pasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.pasteToolStripMenuItem.Text = "&Paste";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.selectAllToolStripMenuItem.Text = "Select &All";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customizeToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // customizeToolStripMenuItem
            // 
            this.customizeToolStripMenuItem.Name = "customizeToolStripMenuItem";
            this.customizeToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.customizeToolStripMenuItem.Text = "&Customize";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.optionsToolStripMenuItem.Text = "&Options";
            // 
            // sToolStripMenuItem
            // 
            this.sToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cameraCaptureToolStripMenuItem,
            this.colorDetectionToolStripMenuItem,
            this.shapeDetectionToolStripMenuItem,
            this.toolStripMenuItem3,
            this.featureExtractionToolStripMenuItem,
            this.toolStripMenuItem1,
            this.faceDetectionToolStripMenuItem,
            this.toolStripMenuItem2,
            this.histogaramToolStripMenuItem,
            this.motionDetectionToolStripMenuItem});
            this.sToolStripMenuItem.Name = "sToolStripMenuItem";
            this.sToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.sToolStripMenuItem.Text = "&SelectProcess";
            // 
            // cameraCaptureToolStripMenuItem
            // 
            this.cameraCaptureToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cameraCaptureToolStripMenuItem.Image")));
            this.cameraCaptureToolStripMenuItem.Name = "cameraCaptureToolStripMenuItem";
            this.cameraCaptureToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.cameraCaptureToolStripMenuItem.Text = "CameraCapture";
            this.cameraCaptureToolStripMenuItem.Click += new System.EventHandler(this.cameraCaptureToolStripMenuItem_Click);
            // 
            // colorDetectionToolStripMenuItem
            // 
            this.colorDetectionToolStripMenuItem.Name = "colorDetectionToolStripMenuItem";
            this.colorDetectionToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.colorDetectionToolStripMenuItem.Text = "ColorDetection";
            this.colorDetectionToolStripMenuItem.Click += new System.EventHandler(this.colorDetectionToolStripMenuItem_Click);
            // 
            // shapeDetectionToolStripMenuItem
            // 
            this.shapeDetectionToolStripMenuItem.Name = "shapeDetectionToolStripMenuItem";
            this.shapeDetectionToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.shapeDetectionToolStripMenuItem.Text = " ShapeDetection";
            this.shapeDetectionToolStripMenuItem.Click += new System.EventHandler(this.shapeDetectionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(162, 6);
            // 
            // featureExtractionToolStripMenuItem
            // 
            this.featureExtractionToolStripMenuItem.Name = "featureExtractionToolStripMenuItem";
            this.featureExtractionToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.featureExtractionToolStripMenuItem.Text = "FeatureExtraction";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(162, 6);
            // 
            // faceDetectionToolStripMenuItem
            // 
            this.faceDetectionToolStripMenuItem.Name = "faceDetectionToolStripMenuItem";
            this.faceDetectionToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.faceDetectionToolStripMenuItem.Text = "FaceDetection";
            this.faceDetectionToolStripMenuItem.Click += new System.EventHandler(this.faceDetectionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(162, 6);
            // 
            // histogaramToolStripMenuItem
            // 
            this.histogaramToolStripMenuItem.Name = "histogaramToolStripMenuItem";
            this.histogaramToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.histogaramToolStripMenuItem.Text = "Histogaram";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.contentsToolStripMenuItem.Text = "&Contents";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.indexToolStripMenuItem.Text = "&Index";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.searchToolStripMenuItem.Text = "&Search";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(119, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aboutToolStripMenuItem.Image")));
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox14);
            this.groupBox9.Controls.Add(this.groupBox12);
            this.groupBox9.Location = new System.Drawing.Point(879, 298);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(282, 361);
            this.groupBox9.TabIndex = 13;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "SerialPort";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.groupBox13);
            this.groupBox17.Location = new System.Drawing.Point(1174, 348);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(184, 311);
            this.groupBox17.TabIndex = 16;
            this.groupBox17.TabStop = false;
            // 
            // shapedetectButton
            // 
            this.shapedetectButton.Enabled = false;
            this.shapedetectButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shapedetectButton.Location = new System.Drawing.Point(323, 285);
            this.shapedetectButton.Name = "shapedetectButton";
            this.shapedetectButton.Size = new System.Drawing.Size(125, 35);
            this.shapedetectButton.TabIndex = 18;
            this.shapedetectButton.Text = "ShapeDetect";
            this.shapedetectButton.UseVisualStyleBackColor = true;
            this.shapedetectButton.Click += new System.EventHandler(this.shapedetectButton_Click);
            // 
            // ShapeDetectionTimer
            // 
            this.ShapeDetectionTimer.Interval = 25;
            this.ShapeDetectionTimer.Tick += new System.EventHandler(this.ShapeDetectionTimer_Tick);
            // 
            // stopShapeButton
            // 
            this.stopShapeButton.Enabled = false;
            this.stopShapeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stopShapeButton.Location = new System.Drawing.Point(453, 285);
            this.stopShapeButton.Name = "stopShapeButton";
            this.stopShapeButton.Size = new System.Drawing.Size(125, 35);
            this.stopShapeButton.TabIndex = 19;
            this.stopShapeButton.Text = "StopShape";
            this.stopShapeButton.UseVisualStyleBackColor = true;
            this.stopShapeButton.Click += new System.EventHandler(this.stopShapeButton_Click);
            // 
            // faceDetectButton
            // 
            this.faceDetectButton.Enabled = false;
            this.faceDetectButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faceDetectButton.Location = new System.Drawing.Point(599, 285);
            this.faceDetectButton.Name = "faceDetectButton";
            this.faceDetectButton.Size = new System.Drawing.Size(125, 35);
            this.faceDetectButton.TabIndex = 20;
            this.faceDetectButton.Text = "FaceDetect";
            this.faceDetectButton.UseVisualStyleBackColor = true;
            this.faceDetectButton.Click += new System.EventHandler(this.faceDetectButton_Click);
            // 
            // stopFaceButton
            // 
            this.stopFaceButton.Enabled = false;
            this.stopFaceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stopFaceButton.Location = new System.Drawing.Point(729, 285);
            this.stopFaceButton.Name = "stopFaceButton";
            this.stopFaceButton.Size = new System.Drawing.Size(125, 35);
            this.stopFaceButton.TabIndex = 21;
            this.stopFaceButton.Text = "StopFace";
            this.stopFaceButton.UseVisualStyleBackColor = true;
            this.stopFaceButton.Click += new System.EventHandler(this.stopFaceButton_Click);
            // 
            // PortTimer
            // 
            this.PortTimer.Interval = 1000;
            this.PortTimer.Tick += new System.EventHandler(this.PortTimer_Tick);
            // 
            // motionDetectionToolStripMenuItem
            // 
            this.motionDetectionToolStripMenuItem.Name = "motionDetectionToolStripMenuItem";
            this.motionDetectionToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.motionDetectionToolStripMenuItem.Text = "MotionDetection";
            this.motionDetectionToolStripMenuItem.Click += new System.EventHandler(this.motionDetectionToolStripMenuItem_Click);
            // 
            // ComputerVision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1370, 679);
            this.Controls.Add(this.stopFaceButton);
            this.Controls.Add(this.faceDetectButton);
            this.Controls.Add(this.stopShapeButton);
            this.Controls.Add(this.shapedetectButton);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.cameraCaptureButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ComputerVision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PardazehComputerVision";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.originalImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cannyImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayscaleImageBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CircleImageBox)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Color_RectImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Thershold_TriangelImageBox)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.His_LineImageBox)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Emgu.CV.UI.ImageBox originalImageBox;
        private System.Windows.Forms.Label label1;
        private Emgu.CV.UI.ImageBox cannyImageBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button cameraCaptureButton;
        private Emgu.CV.UI.ImageBox grayscaleImageBox;
        private System.Windows.Forms.ComboBox RedComboBox;
        private System.Windows.Forms.ComboBox GreenComboBox;
        private System.Windows.Forms.ComboBox BlueComboBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox RedMaxTextBox;
        private System.Windows.Forms.TextBox RedMinTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox ToleranceComboBox;
        private System.Windows.Forms.TextBox ResultMaxTextBox;
        private System.Windows.Forms.TextBox BlueMaxTextBox;
        private System.Windows.Forms.TextBox GreenMaxTextBox;
        private System.Windows.Forms.TextBox GreenMinTextBox;
        private System.Windows.Forms.TextBox BlueMinTextBox;
        private System.Windows.Forms.TextBox ResultMinTextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button ColorSelectButton;
        private System.Windows.Forms.Timer FaceDetectionTimer;
        private System.Windows.Forms.Timer ColorDetectionTimer;
        private Emgu.CV.UI.ImageBox Color_RectImageBox;
        private Emgu.CV.UI.ImageBox Thershold_TriangelImageBox;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox paritycomboBox;
        private System.Windows.Forms.ComboBox databitscomboBox;
        private System.Windows.Forms.ComboBox baudratecomboBox;
        private System.Windows.Forms.ComboBox portnamecomboBox;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox readtextBox;
        private System.Windows.Forms.TextBox writetextBox;
        private System.Windows.Forms.ComboBox stopbitscomboBox;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button ClosePortButton;
        private System.Windows.Forms.Label StopBitsLabel;
        private System.Windows.Forms.Label ParityLabel;
        private System.Windows.Forms.Label DataBitsLabel;
        private System.Windows.Forms.Label BaudRateLabel;
        private System.Windows.Forms.Label PortNameLabel;
        private System.Windows.Forms.Label PortStatusLabel;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button SaveSettingButton;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label TimeOutLabel;
        private System.Windows.Forms.Button SettingPortButton;
        private System.Windows.Forms.Button ReadButton;
        private System.Windows.Forms.Button WriteButton;
        private System.Windows.Forms.Button FlipVButton;
        private System.Windows.Forms.Button FlipHButton;
        private System.Windows.Forms.Button colordetectButton;
        private System.Windows.Forms.Button stopcolorButton;
        private System.Windows.Forms.Label ylabel;
        private System.Windows.Forms.Label xlabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox15;
        private Emgu.CV.UI.ImageBox CircleImageBox;
        private System.Windows.Forms.GroupBox groupBox16;
        private Emgu.CV.UI.ImageBox His_LineImageBox;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button restButton;
        private System.Windows.Forms.Button shapedetectButton;
        private System.Windows.Forms.ToolStripMenuItem sToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cameraCaptureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorDetectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shapeDetectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem featureExtractionToolStripMenuItem;
        private System.Windows.Forms.Timer ShapeDetectionTimer;
        private System.Windows.Forms.Button stopShapeButton;
        private System.Windows.Forms.ToolStripMenuItem faceDetectionToolStripMenuItem;
        private System.Windows.Forms.Button faceDetectButton;
        private System.Windows.Forms.Button stopFaceButton;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem histogaramToolStripMenuItem;
        private System.Windows.Forms.Timer PortTimer;
        private System.Windows.Forms.ToolStripMenuItem motionDetectionToolStripMenuItem;

    }
}

