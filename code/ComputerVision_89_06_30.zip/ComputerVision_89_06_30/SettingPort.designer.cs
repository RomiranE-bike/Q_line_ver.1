﻿namespace PradazehComputerVision
{
    partial class setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(setting));
            this.baudratecombox = new System.Windows.Forms.ComboBox();
            this.stopbitscombox = new System.Windows.Forms.ComboBox();
            this.btnok = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.labbaudrate = new System.Windows.Forms.Label();
            this.labstopbits = new System.Windows.Forms.Label();
            this.databitscombox = new System.Windows.Forms.ComboBox();
            this.paritycombox = new System.Windows.Forms.ComboBox();
            this.portnamecombox = new System.Windows.Forms.ComboBox();
            this.labportname = new System.Windows.Forms.Label();
            this.labdatabits = new System.Windows.Forms.Label();
            this.labparity = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // baudratecombox
            // 
            this.baudratecombox.FormattingEnabled = true;
            this.baudratecombox.Items.AddRange(new object[] {
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200"});
            this.baudratecombox.Location = new System.Drawing.Point(104, 65);
            this.baudratecombox.Name = "baudratecombox";
            this.baudratecombox.Size = new System.Drawing.Size(91, 21);
            this.baudratecombox.TabIndex = 0;
            this.baudratecombox.Text = "9600";
            // 
            // stopbitscombox
            // 
            this.stopbitscombox.FormattingEnabled = true;
            this.stopbitscombox.Items.AddRange(new object[] {
            "None",
            "One",
            "Two",
            "OnePointFive"});
            this.stopbitscombox.Location = new System.Drawing.Point(104, 146);
            this.stopbitscombox.Name = "stopbitscombox";
            this.stopbitscombox.Size = new System.Drawing.Size(91, 21);
            this.stopbitscombox.TabIndex = 1;
            this.stopbitscombox.Text = "One";
            // 
            // btnok
            // 
            this.btnok.Location = new System.Drawing.Point(36, 207);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 23);
            this.btnok.TabIndex = 2;
            this.btnok.Text = "OK";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(117, 207);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 3;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click_1);
            // 
            // labbaudrate
            // 
            this.labbaudrate.AutoSize = true;
            this.labbaudrate.Location = new System.Drawing.Point(33, 68);
            this.labbaudrate.Name = "labbaudrate";
            this.labbaudrate.Size = new System.Drawing.Size(61, 13);
            this.labbaudrate.TabIndex = 4;
            this.labbaudrate.Text = "BaudRate :";
            // 
            // labstopbits
            // 
            this.labstopbits.AutoSize = true;
            this.labstopbits.Location = new System.Drawing.Point(33, 149);
            this.labstopbits.Name = "labstopbits";
            this.labstopbits.Size = new System.Drawing.Size(52, 13);
            this.labstopbits.TabIndex = 5;
            this.labstopbits.Text = "StopBits :";
            // 
            // databitscombox
            // 
            this.databitscombox.FormattingEnabled = true;
            this.databitscombox.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.databitscombox.Location = new System.Drawing.Point(104, 92);
            this.databitscombox.Name = "databitscombox";
            this.databitscombox.Size = new System.Drawing.Size(91, 21);
            this.databitscombox.TabIndex = 6;
            this.databitscombox.Text = "8";
            // 
            // paritycombox
            // 
            this.paritycombox.FormattingEnabled = true;
            this.paritycombox.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.paritycombox.Location = new System.Drawing.Point(104, 119);
            this.paritycombox.Name = "paritycombox";
            this.paritycombox.Size = new System.Drawing.Size(91, 21);
            this.paritycombox.TabIndex = 7;
            this.paritycombox.Text = "None";
            // 
            // portnamecombox
            // 
            this.portnamecombox.FormattingEnabled = true;
            this.portnamecombox.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10",
            "COM11",
            "COM12",
            "COM13",
            "COM14",
            "COM15",
            "COM16"});
            this.portnamecombox.Location = new System.Drawing.Point(104, 38);
            this.portnamecombox.Name = "portnamecombox";
            this.portnamecombox.Size = new System.Drawing.Size(91, 21);
            this.portnamecombox.TabIndex = 8;
            this.portnamecombox.Text = "COM11";
            // 
            // labportname
            // 
            this.labportname.AutoSize = true;
            this.labportname.Location = new System.Drawing.Point(33, 41);
            this.labportname.Name = "labportname";
            this.labportname.Size = new System.Drawing.Size(60, 13);
            this.labportname.TabIndex = 9;
            this.labportname.Text = "PortName :";
            // 
            // labdatabits
            // 
            this.labdatabits.AutoSize = true;
            this.labdatabits.Location = new System.Drawing.Point(33, 95);
            this.labdatabits.Name = "labdatabits";
            this.labdatabits.Size = new System.Drawing.Size(53, 13);
            this.labdatabits.TabIndex = 10;
            this.labdatabits.Text = "DataBits :";
            // 
            // labparity
            // 
            this.labparity.AutoSize = true;
            this.labparity.Location = new System.Drawing.Point(33, 122);
            this.labparity.Name = "labparity";
            this.labparity.Size = new System.Drawing.Size(39, 13);
            this.labparity.TabIndex = 11;
            this.labparity.Text = "Parity :";
            // 
            // setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(225, 275);
            this.Controls.Add(this.labparity);
            this.Controls.Add(this.labdatabits);
            this.Controls.Add(this.labportname);
            this.Controls.Add(this.portnamecombox);
            this.Controls.Add(this.paritycombox);
            this.Controls.Add(this.databitscombox);
            this.Controls.Add(this.labstopbits);
            this.Controls.Add(this.labbaudrate);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.stopbitscombox);
            this.Controls.Add(this.baudratecombox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "setting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SettingSerialPort";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox baudratecombox;
        private System.Windows.Forms.ComboBox stopbitscombox;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Label labbaudrate;
        private System.Windows.Forms.Label labstopbits;
        private System.Windows.Forms.ComboBox databitscombox;
        private System.Windows.Forms.ComboBox paritycombox;
        private System.Windows.Forms.ComboBox portnamecombox;
        private System.Windows.Forms.Label labportname;
        private System.Windows.Forms.Label labdatabits;
        private System.Windows.Forms.Label labparity;
    }
}