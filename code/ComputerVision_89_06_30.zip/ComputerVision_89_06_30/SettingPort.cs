﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PradazehComputerVision
{
    public partial class setting : Form
    {

        public setting()
        {
            InitializeComponent();
        }

//***************************************************************
        //variables for storing values of baud rate and stop bits

        private string baudR = "";
        private string stopB = "";
        private string portN = "";
        private string dataB = "";
        private string parityV = "";
//****************************************************************
        //property for setting and getting baud rate and stop bits
        public string bRate
        {
            get{ return baudR;}
            set{ baudR = value;}
          }

        public string sBits
        {
            get{return stopB;}
            set{stopB = value;}  
        }
        public string pName
        {
            get { return portN; }
            set { portN = value; }
        }
        public string dBits
        {
            get { return dataB; }
            set { dataB = value; }
        }

        public string pValue
        {
            get { return parityV; }
            set { parityV = value; }
        }

//*********************************************************             
       
        private void btnok_Click(object sender, EventArgs e)
        {

         //here we set the value for stop bits and baud rate.

            this.bRate = baudratecombox.Text;
            this.sBits = stopbitscombox.Text;
            this.pName = portnamecombox.Text;
            this.dBits = databitscombox.Text;
            this.pValue = paritycombox.Text;
            //close form
            this.Close();
        }

        private void btncancel_Click_1(object sender, EventArgs e)
        {
            this.bRate = "";
            this.sBits = "";
            //close form
            this.Close();
           
        }
    }
}
    

