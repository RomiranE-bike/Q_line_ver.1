/*****************************************************
This program was produced by the
CodeWizardAVR V2.03.4 Standard
Automatic Program Generator
� Copyright 1998-2008 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : comvision
Version : 3
Date    : 2010/09/07
Author  : esmaeili
Company : Pardazeh
Comments: 


Chip type           : ATmega32
Program type        : Application
Clock frequency     : 12.000000 MHz
Memory model        : Small
External RAM size   : 0
Data Stack size     : 512
*****************************************************/

#include <mega32.h>

// Standard Input/Output functions
#include <stdio.h>
#include <delay.h>

void manual();
void automatic();
void camstepDown();      
void camstepUp();
void mainstepForward();
void mainstepReverse();
void mainstepRun();
void stop();
void reset();
void select();
void run();
void capture();



// Declare your global variables here

void main(void)
{
// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTA=0x00;
DDRA=0xFF;

// Port B initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTB=0x00;
DDRB=0x00;

// Port C initialization
// Func7=Out Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=0 State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTC=0x00;
DDRC=0x80;

// Port D initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTD=0x00;
DDRD=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=FFh
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Normal top=FFFFh
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 9600
UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x4D;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

while (1)
      {
      // Place your code here
      if(PINB.0==1) //manuale mode
      {
      reset();
      manual();
      }
      else if(PINB.1==1)  
      automatic();
      };
}
//**************************
void manual()
{
      reset();
      camstepDown();
      camstepUp();
      mainstepForward();
      mainstepReverse();
}

//****************************
void automatic()
{
                       reset();                                                 //rest system
                       if(PIND.2==1&&PIND.3==1&&PIND.4==1)                      //object is not present inpout.             1  111
                       stop();
                  else if(PIND.2==0&&PIND.3==1&&PIND.4==1)                      //object is on the inpout.                  2  011
                         {
                            do
                            {
                            run();
                           }while(PIND.2==1&&PIND.3==0&&PIND.4==1);    //object is under the camera.                        3  101
                            capture();                          //geting capture and  doing imagprocessing                
                        }
                 else if(PIND.2==1&&PIND.3==1&&PIND.4==0)             //select object.                                      4  110
                        {
                          select();
                        }                                                                                                           
                 else if(PIND.2==0&&PIND.3==0&&PIND.4==0)
                        {                                      //geting capture and  doing imagprocessing                   5  000
                          capture(); 
                          select();
                          run();                                                                                    
                        }
                                                            
                 else if(PIND.2==0&&PIND.3==0&&PIND.4==1)                                                                // 6  001
                        {
                         capture();                           //geting capture and  doing imagprocessing    
                         run();                                 
                        }
                                         
                 else if(PIND.2==0&&PIND.3==1&&PIND.4==0)                                                              //  7  010
                        {
                         select();
                         run();
                        }
                 
                 else if(PIND.2==1&&PIND.3==0&&PIND.4==0) 
                        {                                    //geting capture and  doing imagprocessing                   8 100
                         capture();
                         select();
                        } 
                        
                        else 
                        reset();                                                                                                     
}

void stop()
{
PORTA=0x00;
}

void select()
{
  stop();
  reset();
}

void run()
{
mainstepRun();
}

void capture()
{
  stop();
   delay_ms(3000);                          //geting capture and  doing imagprocessing
     do{
       run();
       }while(PIND.2==1&&PIND.3==1&&PIND.4==0);   //object is end of line. 
}

void reset()
{
PORTC.7=1;
delay_ms(1);
PORTC.7=0;
}
//**********************************
void camstepDown()
{
PORTA=0x00;     //reset PORTA
while(PINB.7==1)       //sw6
{
PORTA.3=0,PORTA.2=0,PORTA.1=0,PORTA.0=1;  //step 1   0001
delay_ms(100);
PORTA.3=0,PORTA.2=0,PORTA.1=1,PORTA.0=0;  //step 2   0010
delay_ms(100);
PORTA.3=0,PORTA.2=1,PORTA.1=0,PORTA.0=0;  //step 3   0100
delay_ms(100);
PORTA.3=1,PORTA.2=0,PORTA.1=0,PORTA.0=0;  //step 4   1000
delay_ms(100);
/*
PORTA.3=0,PORTA.2=1,PORTA.1=0,PORTA.0=0;  //step 5   0100
delay_ms(10);
PORTA.3=1,PORTA.2=1,PORTA.1=0,PORTA.0=0;  //step 6   1100
delay_ms(10);
PORTA.3=1,PORTA.2=0,PORTA.1=0,PORTA.0=0;  //step 7   1000
delay_ms(10);
PORTA.3=1,PORTA.2=0,PORTA.1=0,PORTA.0=1;  //step 8   1001
delay_ms(10);*/
};
PORTA=0x00;  //reset PORTA
}
//*************************************

void camstepUp()
{
PORTA=0x00;    //reset PORTA
while(PINB.6==1)    //sw5
{
/*
PORTA.3=1,PORTA.2=0,PORTA.1=0,PORTA.0=1;  //step 8   1001
delay_ms(10);
PORTA.3=1,PORTA.2=0,PORTA.1=0,PORTA.0=0;  //step 7   1000
delay_ms(10);
PORTA.3=1,PORTA.2=1,PORTA.1=0,PORTA.0=0;  //step 6   1100
delay_ms(10);
PORTA.3=0,PORTA.2=1,PORTA.1=0,PORTA.0=0;  //step 5   0100
delay_ms(10);*/
PORTA.3=1,PORTA.2=0,PORTA.1=0,PORTA.0=0;  //step 4   1000
delay_ms(100);
PORTA.3=0,PORTA.2=1,PORTA.1=0,PORTA.0=0;  //step 3   0100
delay_ms(100);
PORTA.3=0,PORTA.2=0,PORTA.1=1,PORTA.0=0;  //step 2   0010
delay_ms(100);
PORTA.3=0,PORTA.2=0,PORTA.1=0,PORTA.0=1;  //step 1   0001
delay_ms(100);
};
PORTA=0x00;   //reset PORTA
}
//***********************************************

void mainstepForward()
{
PORTA=0x00; //reset  PORTA
while(PINB.5==1)   // sw8
{
PORTA.7=0,PORTA.6=0,PORTA.5=0,PORTA.4=1;  //step 1   0001
delay_ms(100);
PORTA.7=0,PORTA.6=0,PORTA.5=1,PORTA.4=0;  //step 2   0010
delay_ms(100);
PORTA.7=0,PORTA.6=1,PORTA.5=0,PORTA.4=0;  //step 3   0100
delay_ms(100);
PORTA.7=1,PORTA.6=0,PORTA.5=0,PORTA.4=0;  //step 4   1000
delay_ms(100);
};
PORTA=0x00;  //reset PORTA
}

//************************************************
void mainstepReverse() //sw7
{
PORTA=0x00; // reset  PORTA
while(PINB.4==1)
{
PORTA.7=1,PORTA.6=0,PORTA.5=0,PORTA.4=0;  //step 4   1000
delay_ms(100);
PORTA.7=0,PORTA.6=1,PORTA.5=0,PORTA.4=0;  //step 3   0100
delay_ms(100);
PORTA.7=0,PORTA.6=0,PORTA.5=1,PORTA.4=0;  //step 2   0010
delay_ms(100);
PORTA.7=0,PORTA.6=0,PORTA.5=0,PORTA.4=1;  //step 1   0001
delay_ms(100);
};

PORTA=0x00;   //reset  PORTA
}
//***********************************************

void mainstepRun()
{
PORTA=0x00;     //reset   PORTA
while(PINB.1==1)   // sw1
{
PORTA.7=0,PORTA.6=0,PORTA.5=0,PORTA.4=1;  //step 1   0001
delay_ms(10);
PORTA.7=0,PORTA.6=0,PORTA.5=1,PORTA.4=0;  //step 2   0011
delay_ms(10);
PORTA.7=0,PORTA.6=1,PORTA.5=0,PORTA.4=0;  //step 3   0010
delay_ms(10);
PORTA.7=1,PORTA.6=0,PORTA.5=0,PORTA.4=0;  //step 4   0110
delay_ms(10);
};
PORTA=0x00; //reset     PORTA
}
